<?php
/**
 * Nuvora Panel
 *
 * Custom blocks have been removed to comply with WordPress.org theme requirements
 * (Section 5: Themes must not include custom blocks).
 * Panels are rendered via front-page.php from pages linked in the navigation menu.
 *
 * @package NuvoraDimension
 */
