<?php
/**
 * Nuvora Hero Block
 *
 * Custom blocks have been removed to comply with WordPress.org theme requirements
 * (Section 5: Themes must not include custom blocks).
 * The hero header is configured via Appearance > Theme Options.
 *
 * @package NuvoraDimension
 */
